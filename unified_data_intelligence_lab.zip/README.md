# Unified Data Intelligence Lab

Provenance-first data search foundation.

## Absolute rule
The database is the only source of truth. The AI may interpret search intent or explain database results, but it must NEVER invent a fact. If a requested value is absent, return `לא נמצא` / `NOT FOUND`.

## Run
Python 3.11+
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export ADMIN_PASSWORD='use-a-long-random-password'
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Prototype features
- Admin-only login
- TXT/CSV/TSV/JSONL upload
- Streaming ingestion
- Raw-record preservation
- Basic schema/field profiling
- Deterministic normalization/search
- Source provenance
- Conservative matching
- No name-only automatic merge

For production, replace the demo auth/session, use PostgreSQL + object storage + background workers, HTTPS, rate limits, backups and a proper audit/security review.
