
import os, re, csv, json, sqlite3, hashlib, secrets
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

BASE=Path(__file__).resolve().parent.parent
DATA=BASE/"data"; DATA.mkdir(exist_ok=True)
DB=DATA/"lab.sqlite3"
ADMIN_USER=os.getenv("ADMIN_USER","admin")
ADMIN_PASSWORD=os.getenv("ADMIN_PASSWORD","CHANGE-ME-IMMEDIATELY")

app=FastAPI(title="Unified Data Intelligence Lab")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS sources(
      id INTEGER PRIMARY KEY, name TEXT, filename TEXT, size INTEGER,
      status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS raw_records(
      id INTEGER PRIMARY KEY, source_id INTEGER, row_number INTEGER,
      raw_text TEXT, parsed_json TEXT);
    CREATE TABLE IF NOT EXISTS fields(
      id INTEGER PRIMARY KEY, source_id INTEGER, column_name TEXT,
      semantic_type TEXT, confidence REAL);
    CREATE TABLE IF NOT EXISTS values_index(
      id INTEGER PRIMARY KEY, source_id INTEGER, record_id INTEGER,
      column_name TEXT, raw_value TEXT, normalized_value TEXT, semantic_type TEXT);
    CREATE INDEX IF NOT EXISTS idx_vi_norm ON values_index(semantic_type,normalized_value);
    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY, action TEXT, details TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    """); c.commit(); c.close()
init()

def audit(a,d):
    c=conn(); c.execute("INSERT INTO audit(action,details) VALUES(?,?)",(a,d)); c.commit(); c.close()

def ntext(v): return re.sub(r"\s+"," ",str(v or "").strip().casefold())
def nphone(v):
    s=re.sub(r"\D","",str(v or ""))
    if s.startswith("00"): s=s[2:]
    if s.startswith("0") and len(s)==10: s="972"+s[1:]
    return s
def nid(v):
    s=re.sub(r"\D","",str(v or ""))
    return s.zfill(9) if s else ""
def nemail(v): return str(v or "").strip().casefold()

def guess(name,samples):
    n=ntext(name).replace("_"," ").replace("-"," ")
    if any(x in n for x in ["phone","mobile","cell","telephone","טלפון","נייד"]): return "PHONE",.98
    if any(x in n for x in ["email","mail","אימייל","מייל"]): return "EMAIL",.98
    if any(x in n for x in ["facebook id","fb id","facebook_id"]): return "FACEBOOK_ID",.99
    if any(x in n for x in ["national id","identity","id number","תעודת זהות","תז"]): return "NATIONAL_ID",.95
    if any(x in n for x in ["first name","fname","given","שם פרטי"]): return "FIRST_NAME",.98
    if any(x in n for x in ["last name","lname","surname","family","שם משפחה"]): return "LAST_NAME",.98
    if any(x in n for x in ["birth","dob","date of birth","לידה"]): return "BIRTH_DATE",.95
    if any(x in n for x in ["city","עיר","יישוב"]): return "CITY",.9
    if any(x in n for x in ["address","street","כתובת","רחוב"]): return "ADDRESS",.9
    vals=[str(x).strip() for x in samples if str(x).strip()]
    if vals:
        ph=sum(bool(re.fullmatch(r"[+0-9 ()-]{7,20}",x)) for x in vals)/len(vals)
        em=sum("@" in x for x in vals)/len(vals)
        if ph>.8:return "PHONE",.75
        if em>.8:return "EMAIL",.75
    return "UNKNOWN",0

def normalize(t,v):
    return {"PHONE":nphone,"NATIONAL_ID":nid,"EMAIL":nemail}.get(t,ntext)(v)

def dialect(sample):
    try: text=sample.decode("utf-8")
    except: text=sample.decode("cp1255",errors="replace")
    lines=[x for x in text.splitlines() if x][:20]
    ds=[",","\t",";","|"]
    d=max(ds,key=lambda x:sum(line.count(x) for line in lines)) if lines else ","
    return text,d

def require_admin(req):
    tok=req.cookies.get("admin_token")
    expected=hashlib.sha256((ADMIN_USER+"|"+ADMIN_PASSWORD).encode()).hexdigest()
    if not tok or not secrets.compare_digest(tok,expected): raise HTTPException(401,"Admin login required")

@app.get("/",response_class=HTMLResponse)
def home(): return HTML

@app.post("/api/login")
def login(username:str=Form(...),password:str=Form(...)):
    if not (secrets.compare_digest(username,ADMIN_USER) and secrets.compare_digest(password,ADMIN_PASSWORD)):
        raise HTTPException(401,"Invalid credentials")
    token=hashlib.sha256((username+"|"+password).encode()).hexdigest()
    r=JSONResponse({"ok":True}); r.set_cookie("admin_token",token,httponly=True,samesite="strict"); return r

@app.post("/api/upload")
async def upload(request:Request,file:UploadFile=File(...)):
    require_admin(request)
    name=Path(file.filename or "dataset").name
    path=DATA/(hashlib.sha256((name+secrets.token_hex(8)).encode()).hexdigest()+"_"+name)
    size=0
    with open(path,"wb") as out:
        while True:
            b=await file.read(1024*1024)
            if not b: break
            out.write(b); size+=len(b)
    with open(path,"rb") as f: sample=f.read(1024*1024)
    _,d=dialect(sample)
    suffix=path.suffix.lower()
    cols=[]; samples={}
    if suffix in [".csv",".tsv",".txt"]:
        delim="\t" if suffix==".tsv" else d
        with open(path,"r",encoding="utf-8",errors="replace",newline="") as f:
            reader=csv.reader(f,delimiter=delim); first=next(reader,[])
            cols=[str(x).strip() or f"column_{i+1}" for i,x in enumerate(first)]
            samples={x:[] for x in cols}
            for row in reader:
                for i,col in enumerate(cols):
                    if i<len(row) and len(samples[col])<100:samples[col].append(row[i])
                if all(len(v)>=100 for v in samples.values()):break
    elif suffix==".jsonl":
        with open(path,"r",encoding="utf-8",errors="replace") as f:
            for line in f:
                if line.strip():
                    obj=json.loads(line); cols=list(obj); samples={x:[] for x in cols}
                    for x in cols:samples[x].append(obj.get(x,""))
                    break
    else: cols=["value"]; samples={"value":[]}
    c=conn(); cur=c.execute("INSERT INTO sources(name,filename,size,status) VALUES(?,?,?,?)",(name,name,size,"READY_FOR_IMPORT")); sid=cur.lastrowid
    for col in cols:
        t,conf=guess(col,samples[col]); c.execute("INSERT INTO fields(source_id,column_name,semantic_type,confidence) VALUES(?,?,?,?)",(sid,col,t,conf))
    c.commit(); c.close(); audit("ANALYZE",f"source={sid},columns={len(cols)}")
    return {"source_id":sid,"filename":name,"size":size,"delimiter":d,"columns":[{"name":c,"semantic_type":guess(c,samples[c])[0],"confidence":guess(c,samples[c])[1]} for c in cols]}

@app.post("/api/import/{sid}")
def do_import(sid:int,request:Request):
    require_admin(request)
    c=conn(); src=c.execute("SELECT * FROM sources WHERE id=?",(sid,)).fetchone()
    fields=c.execute("SELECT * FROM fields WHERE source_id=?",(sid,)).fetchall(); c.close()
    if not src: raise HTTPException(404,"Source not found")
    matches=list(DATA.glob("*_"+Path(src["filename"]).name))
    if not matches: raise HTTPException(404,"Stored file not found")
    path=matches[-1]; mapping={x["column_name"]:x["semantic_type"] for x in fields}
    with open(path,"rb") as f: sample=f.read(1024*1024)
    _,d=dialect(sample); delim="\t" if path.suffix.lower()==".tsv" else d
    c=conn(); c.execute("UPDATE sources SET status='IMPORTING' WHERE id=?",(sid,)); c.commit()
    rowno=0; batch=[]
    try:
        if path.suffix.lower()==".jsonl":
            iterator=(json.loads(x) for x in open(path,"r",encoding="utf-8",errors="replace") if x.strip())
            for obj in iterator:
                rowno+=1; batch.append((sid,rowno,json.dumps(obj,ensure_ascii=False),json.dumps(obj,ensure_ascii=False)))
                if len(batch)>=5000:
                    c.executemany("INSERT INTO raw_records(source_id,row_number,raw_text,parsed_json) VALUES(?,?,?,?)",batch); c.commit(); batch=[]
        else:
            with open(path,"r",encoding="utf-8",errors="replace",newline="") as f:
                reader=csv.reader(f,delimiter=delim); headers=[str(x).strip() or f"column_{i+1}" for i,x in enumerate(next(reader,[]))]
                for row in reader:
                    rowno+=1; obj={headers[i]:row[i] if i<len(row) else "" for i in range(len(headers))}
                    batch.append((sid,rowno,delim.join(row),json.dumps(obj,ensure_ascii=False)))
                    if len(batch)>=5000:
                        c.executemany("INSERT INTO raw_records(source_id,row_number,raw_text,parsed_json) VALUES(?,?,?,?)",batch); c.commit(); batch=[]
        if batch:c.executemany("INSERT INTO raw_records(source_id,row_number,raw_text,parsed_json) VALUES(?,?,?,?)",batch); c.commit()
        c.execute("UPDATE sources SET status='COMPLETED' WHERE id=?",(sid,)); c.commit(); audit("IMPORT",f"source={sid},rows={rowno}")
        return {"ok":True,"rows":rowno}
    except Exception as e:
        c.execute("UPDATE sources SET status='FAILED' WHERE id=?",(sid,)); c.commit(); raise HTTPException(500,f"Import failed at row {rowno}: {e}")

@app.get("/api/sources")
def sources(request:Request):
    require_admin(request); c=conn(); rows=c.execute("SELECT * FROM sources ORDER BY id DESC").fetchall(); c.close(); return [dict(x) for x in rows]

@app.get("/api/search")
def search(request:Request,q:str,source_id:Optional[int]=None,limit:int=50):
    require_admin(request); q=q.strip()
    if not q:return {"results":[],"message":"לא נמצא"}
    p=nphone(q); i=nid(q) if re.fullmatch(r"\d{7,10}",re.sub(r"\D","",q)) else ""; e=nemail(q); t=ntext(q)
    c=conn(); sql="""SELECT vi.*,s.name source_name,rr.row_number,rr.raw_text,rr.parsed_json
    FROM values_index vi JOIN sources s ON s.id=vi.source_id JOIN raw_records rr ON rr.id=vi.record_id
    WHERE (vi.normalized_value IN (?,?,?) OR vi.normalized_value LIKE ?)"""
    params=[p,i,e,"%"+t+"%"]
    if source_id:sql+=" AND vi.source_id=?";params.append(source_id)
    sql+=" LIMIT ?";params.append(limit)
    rows=c.execute(sql,params).fetchall();c.close()
    out=[]
    for r in rows:
        out.append({"source":r["source_name"],"record_id":r["record_id"],"row_number":r["row_number"],"matched_field":r["column_name"],"raw_value":r["raw_value"],"normalized_value":r["normalized_value"],"confidence":"VERIFIED" if r["normalized_value"] in [p,i,e] and r["normalized_value"] else "POSSIBLE MATCH","raw_record":json.loads(r["parsed_json"]) if r["parsed_json"] else r["raw_text"]})
    return {"query":q,"results":out,"message":None if out else "לא נמצא"}

HTML=r"""<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Unified Data Intelligence Lab</title><style>body{font-family:Arial;max-width:1100px;margin:30px auto;padding:15px;background:#f6f7f9}.card{background:#fff;padding:18px;margin:12px 0;border:1px solid #ddd;border-radius:14px}input,button{padding:10px;margin:4px;border-radius:8px;border:1px solid #aaa}button{cursor:pointer}pre{white-space:pre-wrap;background:#f1f1f1;padding:10px}</style></head><body><h1>Unified Data Intelligence Lab</h1><p>מקור האמת היחיד: הנתונים שנמצאים במאגרים. אם אין נתון — מוצג "לא נמצא".</p><div id="login" class="card"><h2>Admin</h2><form onsubmit="login(event)"><input id="u" value="admin"><input id="p" type="password" placeholder="Password"><button>כניסה</button></form></div><div id="app" style="display:none"><div class="card"><h2>העלאת קובץ</h2><input id="f" type="file"><button onclick="up()">ניתוח</button><pre id="a"></pre></div><div class="card"><h2>חיפוש</h2><input id="q" style="width:70%" placeholder="שם / טלפון / ID / כתובת / אימייל..."><button onclick="go()">חפש</button><div id="r"></div></div><div class="card"><h2>מקורות</h2><button onclick="load()">רענן</button><div id="s"></div></div></div><script>
async function login(e){e.preventDefault();let d=new FormData();d.append("username",u.value);d.append("password",p.value);let x=await fetch("/api/login",{method:"POST",body:d});if(x.ok){loginBox.style.display="none";app.style.display="block";load()}else alert("כניסה נכשלה")}
const loginBox=document.getElementById("login");
async function up(){let x=f.files[0];if(!x)return;let d=new FormData();d.append("file",x);let z=await(await fetch("/api/upload",{method:"POST",body:d})).json();a.textContent=JSON.stringify(z,null,2);if(z.source_id&&confirm("הניתוח הסתיים. להתחיל Import?")){let y=await(await fetch("/api/import/"+z.source_id,{method:"POST"})).json();a.textContent+= "\\nIMPORT:\\n"+JSON.stringify(y,null,2);load()}}
async function go(){let x=await(await fetch("/api/search?q="+encodeURIComponent(q.value))).json();r.innerHTML=x.results.length?x.results.map(v=>`<div class="card"><b>${esc(v.source)}</b> · ${esc(v.confidence)}<br>שדה: ${esc(v.matched_field)}<br>ערך: <b>${esc(v.raw_value)}</b><br>Record ${v.record_id}, שורה ${v.row_number}<details><summary>רשומה מקורית</summary><pre>${esc(JSON.stringify(v.raw_record,null,2))}</pre></details></div>`).join(""):"<h3>לא נמצא</h3>"}
async function load(){let x=await(await fetch("/api/sources")).json();s.innerHTML=x.map(v=>`<div class="card"><b>${esc(v.name)}</b><br>${esc(v.status)} · ${v.size} bytes</div>`).join("")}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
</script></body></html>"""
